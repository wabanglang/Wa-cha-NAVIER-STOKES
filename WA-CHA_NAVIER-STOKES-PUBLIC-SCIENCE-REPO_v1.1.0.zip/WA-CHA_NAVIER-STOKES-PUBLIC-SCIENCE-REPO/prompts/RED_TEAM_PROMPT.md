# Independent Red-Team Prompt

Attempt to disprove or materially weaken the proposed result. Preserve the original theorem and proof text; do not silently repair it.

Search specifically for:

- a mismatch between Clay C/D and the formal theorem;
- missing smoothness at `t = 0`, `t = 1`, spatial boundaries, or localization seams;
- an illegal weak-to-strong or local-to-global upgrade;
- circular dependence among parameter choices;
- nonuniform constants represented as uniform;
- unjustified exchange of limits, derivatives, integrals, or infinite sums;
- convergence insufficient for the claimed derivative order;
- a pressure, support, incompressibility, or energy mismatch;
- uniqueness invoked outside its hypotheses;
- structure fields that assume a critical mathematical result;
- imported axioms, opaque declarations, placeholders, or unsafe code that can reach the main theorem;
- a formal definition that becomes vacuous through junk values or insufficient differentiability hypotheses.

For every suspected defect provide: exact file/page/line, proposition, dependency, minimal counterargument, severity, downstream impact, and a reproducible test. Classify it as `NOT-A-DEFECT`, `PRESENTATIONAL`, `LOCAL-REPAIRABLE`, `MAJOR`, `THEOREM-FATAL`, or `UNRESOLVED`.

