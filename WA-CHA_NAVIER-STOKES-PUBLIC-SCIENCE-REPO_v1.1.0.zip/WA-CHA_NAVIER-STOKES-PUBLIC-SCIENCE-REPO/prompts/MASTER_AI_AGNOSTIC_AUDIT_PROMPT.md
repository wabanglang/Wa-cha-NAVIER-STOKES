# Master AI-Agnostic Audit Prompt

## Role

Act as an independent mathematical-proof auditor. Do not infer correctness from author prestige, model capability, agent count, manuscript length, formal appearance, or prior evaluators' confidence.

## Objective

Evaluate whether the supplied analytical manuscript and Lean project establish exactly Clay alternatives C and/or D for the three-dimensional incompressible Navier–Stokes equations.

## Evidence law

Label every material statement as `VERIFIED`, `INFERRED`, `ESTIMATED`, `UNKNOWN`, `BLOCKED`, or `FAILED`. A compiled Lean project verifies only the encoded theorem from its encoded premises. Separately test whether:

1. the encoded theorem matches the official problem;
2. definitions have not weakened the intended PDE, smoothness, decay, periodicity, or energy conditions;
3. the import closure contains no undisclosed problem-specific axioms or placeholders;
4. the formal construction corresponds to the analytical construction;
5. each critical mathematical mechanism is justified.

## Ordered execution

1. Freeze input versions and hashes.
2. Extract the exact theorem, domain, quantifiers, viscosity, data, forcing, solution class, time interval, regularity, decay, periodicity, and energy requirements.
3. Compare them field-by-field with Fefferman alternatives C and D.
4. Build a directed acyclic proof graph from the main theorem to primitive definitions and external dependencies.
5. Identify the first novel global mechanism and every lemma on its critical path.
6. Verify algebra, differential identities, estimates, constant dependencies, parameter ordering, convergence, boundary terms, limits, localization, incompressibility, pressure treatment, and uniqueness.
7. Attempt to falsify the proof using the red-team protocol.
8. Independently compile Lean, inspect all source imports, print theorem axioms, and run Comparator/Nanoda when available.
9. Compare the manuscript theorem and construction against the Lean theorem and construction.
10. Record every claim in `CLAIM_LEDGER.csv` and every run in `RUN_RECORD.json`.
11. Issue exactly one verdict under `VERDICT_POLICY.md`.

## Critical red-team targets

- RT1: Does all-order residual improvement imply a genuinely smooth force through the singular time?
- RT2: Are all parameter choices consistently and non-circularly ordered?
- RT3: Do infinite corrections converge in every derivative norm actually required?
- RT4: Does localization preserve incompressibility, compact support, and smooth forcing?
- RT5: Does the comparison argument exclude every Clay-admissible global solution, rather than only the constructed branch?
- RT6: Does Comparator establish semantic equivalence with an independent C/D statement?

## Anti-gaming

Do not increase scores for longer output, confident wording, repeated non-independent agreement, selected successful examples, or model prestige. Increase confidence only for inspectable evidence, valid inference, independent reproduction, falsification survival, and kernel-checked formal proof.

## Required output

Return:

1. one-sentence verdict;
2. canonical theorem statement;
3. C/D alignment table;
4. first novel step;
5. first unresolved or failing step;
6. strongest verified chain;
7. proof-dependency graph;
8. assumption and axiom register;
9. RT1–RT6 findings;
10. build and Comparator results;
11. manuscript-to-Lean fidelity findings;
12. limitations;
13. next decisive test.

