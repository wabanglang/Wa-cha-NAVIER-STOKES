# Generated Results

`scripts/run_all.sh` and `scripts/run_all.ps1` create `results/latest/` and place raw logs, status files, source scans, environment metadata, and a preliminary machine report inside it.

Do not overwrite evidence from a completed review. Rename `latest` to the run ID or copy it to immutable storage first.

