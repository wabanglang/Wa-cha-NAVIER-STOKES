# Verdict Policy

Issue exactly one primary verdict:

- `VERIFIED`: every critical dependency passed, scope matches C/D, independent compilation and comparison passed, and no fatal issue remains.
- `CONDITIONALLY_VALID`: the reasoning establishes a strict subcase or requires added hypotheses.
- `INCOMPLETE`: one or more essential claims remain unproved or unaudited.
- `INVALID`: a reproducible fatal defect prevents the conclusion.
- `INDETERMINATE`: the available evidence cannot support an honest decision.

Use separate process labels:

- `SELF_VERIFIED`
- `INDEPENDENTLY_COMPILED`
- `INDEPENDENTLY_REPLICATED`
- `EXPERT_REVIEWED`
- `COMMUNITY_ACCEPTED`
- `CLAY_RECOGNIZED`

These labels are not interchangeable. Clay recognition is external and must never be inferred from compilation or internal verification.

