# Canonical Benchmark Protocol

## Fixed subject

The analytical manuscript and Lean formalization referenced in `evidence/SOURCES.md`.

## Fixed baseline

The official Fefferman formulation of alternatives C and D.

## Reproducible phases

### P0 — Provenance

Record retrieval time, repository URL, commit, branch, toolchain, dependency revisions, host platform, and hashes.

### P1 — Mechanical reproduction

Run the complete build, top-level theorem compilation, source scan, theorem axiom printout, and Comparator/Nanoda if available. Preserve raw logs and exit codes.

### P2 — Theorem alignment

Map every Clay requirement to the exact Lean field or proposition. Treat comments as non-evidence. Mark missing, stronger, weaker, and differently scoped fields.

### P3 — Import-closure integrity

Inspect every reachable source file for `sorry`, `admit`, `axiom`, `unsafe`, custom quotient/soundness assumptions, native code shortcuts, opaque trusted binaries, and theorem-shaped structure fields supplied rather than proved.

### P4 — Critical-path proof audit

Trace candidate construction, convergence, residual cancellation, force extension, localization, blowup, lifespan, uniqueness, viscosity rescaling, and C/D adapters.

### P5 — Semantic fidelity

Compare each major analytical proposition to its formal counterpart. Record anything formalized more weakly, conditionally, abstractly, or by a substituted premise.

### P6 — Independent falsification

Run RT1–RT6 using reviewers who did not produce the proof. Independence must be disclosed.

### P7 — Verdict

Apply `VERDICT_POLICY.md`. Never convert `UNKNOWN` into `PASS`.

## Metrics

- Claim coverage
- Critical-path coverage
- Dependency closure
- C/D scope fidelity
- Placeholder/axiom integrity
- Independent build reproducibility
- Comparator result
- Analytical-to-formal fidelity
- Adversarial survival
- Independent expert agreement

Any unresolved theorem-fatal dependency sets canonical proof readiness to zero until resolved.

