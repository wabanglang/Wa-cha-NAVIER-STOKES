# Expected Main Theorem Interfaces

## Alternative C — whole space

For every positive viscosity, there must exist admissible smooth, rapidly decaying initial data and forcing for which no global smooth solution with uniformly bounded kinetic energy exists on `R^3`.

Expected Lean declaration:

`NavierStokes.Comparator.navier_stokes_breakdown_R3`

## Alternative D — periodic space

For every positive viscosity, there must exist admissible smooth periodic initial data and forcing for which no global smooth periodic solution exists on `R^3/Z^3`.

Expected Lean declaration:

`NavierStokes.Comparator.navier_stokes_breakdown_periodic`

The benchmark must inspect definitions, not names or comments alone.

