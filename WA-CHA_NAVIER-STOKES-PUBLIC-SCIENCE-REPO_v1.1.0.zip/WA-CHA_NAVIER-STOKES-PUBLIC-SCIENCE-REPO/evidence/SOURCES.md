# Authoritative Source Registry

- OpenAI announcement: https://openai.com/index/navier-stokes-solution/
- Analytical manuscript: https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf
- Lean repository: https://github.com/openai/NavierStokesAndEuler
- Official Clay problem description: https://www.claymath.org/wp-content/uploads/2022/06/navierstokes.pdf
- Clay problem status: https://www.claymath.org/millennium/navier-stokes-equation/
- Clay prize rules: https://www.claymath.org/millennium-problems/rules/

Record retrieval dates, content hashes, commit identifiers, and archived copies before a formal audit. Websites and repositories can change.

