#!/usr/bin/env sh
set -u

REPO_DIR="${1:-proof-source}"
OUT_DIR="${2:-results/latest}"
mkdir -p "$OUT_DIR"

if [ ! -d "$REPO_DIR" ]; then
  printf '%s\n' "Repository directory not found: $REPO_DIR" >&2
  exit 2
fi

SCAN_FILE="$OUT_DIR/source-scan.txt"
: > "$SCAN_FILE"

if command -v rg >/dev/null 2>&1; then
  rg -n '\bsorry\b|\badmit\b|\baxiom\b|\bunsafe\b' "$REPO_DIR" --glob '*.lean' > "$SCAN_FILE" 2>&1 || true
else
  find "$REPO_DIR" -type f -name '*.lean' -exec grep -nEH '\bsorry\b|\badmit\b|\baxiom\b|\bunsafe\b' {} + > "$SCAN_FILE" 2>&1 || true
fi

{
  printf '%s\n' "SCAN_NOTICE=Every hit requires human classification; comments and legitimate declarations are not automatically defects."
  printf 'SCAN_LINES=%s\n' "$(wc -l < "$SCAN_FILE" | tr -d ' ')"
} > "$OUT_DIR/scan-status.txt"

find "$REPO_DIR" -type f -name '*.lean' | sort > "$OUT_DIR/lean-file-list.txt"

if command -v sha256sum >/dev/null 2>&1; then
  find "$REPO_DIR" -type f -name '*.lean' -print0 | sort -z | xargs -0 sha256sum > "$OUT_DIR/lean-sha256.txt"
elif command -v shasum >/dev/null 2>&1; then
  find "$REPO_DIR" -type f -name '*.lean' -print0 | sort -z | xargs -0 shasum -a 256 > "$OUT_DIR/lean-sha256.txt"
fi
