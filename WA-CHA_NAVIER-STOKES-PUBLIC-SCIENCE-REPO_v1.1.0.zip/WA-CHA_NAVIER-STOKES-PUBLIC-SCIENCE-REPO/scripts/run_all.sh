#!/usr/bin/env sh
set -u

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
REPO_DIR="$ROOT_DIR/proof-source"
OUT_DIR="$ROOT_DIR/results/latest"
REPO_URL="https://github.com/openai/NavierStokesAndEuler.git"

mkdir -p "$OUT_DIR"
: > "$OUT_DIR/run.log"

log() {
  printf '%s\n' "$*" | tee -a "$OUT_DIR/run.log"
}

run_logged() {
  NAME="$1"
  shift
  log "BEGIN:$NAME"
  "$@" > "$OUT_DIR/$NAME.log" 2>&1
  CODE=$?
  printf '%s\n' "$CODE" > "$OUT_DIR/$NAME.exit-code"
  log "END:$NAME:EXIT=$CODE"
  return "$CODE"
}

log "WA-CHA_CANONICAL_BENCHMARK_START"
date -u '+UTC=%Y-%m-%dT%H:%M:%SZ' > "$OUT_DIR/environment.txt"
uname -a >> "$OUT_DIR/environment.txt" 2>&1 || true

if ! command -v git >/dev/null 2>&1; then
  log "BLOCKED:git-not-found"
  exit 10
fi

if [ ! -d "$REPO_DIR/.git" ]; then
  run_logged clone git clone "$REPO_URL" "$REPO_DIR" || exit 11
else
  log "REUSE:existing-proof-source"
fi

git -C "$REPO_DIR" rev-parse HEAD > "$OUT_DIR/commit.txt" 2>&1
git -C "$REPO_DIR" status --short > "$OUT_DIR/git-status.txt" 2>&1

if ! command -v lake >/dev/null 2>&1; then
  log "BLOCKED:lake-not-found; install elan from https://lean-lang.org/install/"
  sh "$ROOT_DIR/scripts/audit_repository.sh" "$REPO_DIR" "$OUT_DIR"
  exit 12
fi

lake --version >> "$OUT_DIR/environment.txt" 2>&1 || true
lean --version >> "$OUT_DIR/environment.txt" 2>&1 || true

cd "$REPO_DIR" || exit 13
run_logged cache lake exe cache get || log "WARNING:cache-fetch-failed; continuing"
run_logged build lake build
BUILD_CODE=$?
run_logged main-theorem lake env lean NavierStokes.lean
MAIN_CODE=$?

sh "$ROOT_DIR/scripts/audit_repository.sh" "$REPO_DIR" "$OUT_DIR"

if command -v landrun >/dev/null 2>&1 && command -v lean4export >/dev/null 2>&1 && command -v nanoda_bin >/dev/null 2>&1; then
  run_logged comparator lake exe comparator ComparatorChallenges/NavierStokes.json
  COMPARATOR_CODE=$?
else
  COMPARATOR_CODE=125
  printf '%s\n' "SKIPPED: landrun, lean4export, and/or nanoda_bin not available on PATH" > "$OUT_DIR/comparator.log"
  printf '%s\n' "$COMPARATOR_CODE" > "$OUT_DIR/comparator.exit-code"
fi

{
  printf 'BUILD_EXIT=%s\n' "$BUILD_CODE"
  printf 'MAIN_THEOREM_EXIT=%s\n' "$MAIN_CODE"
  printf 'COMPARATOR_EXIT=%s\n' "$COMPARATOR_CODE"
  if [ "$BUILD_CODE" -eq 0 ] && [ "$MAIN_CODE" -eq 0 ]; then
    printf '%s\n' "PRELIMINARY_STATUS=INDEPENDENTLY_COMPILED"
  else
    printf '%s\n' "PRELIMINARY_STATUS=FAILED_OR_BLOCKED"
  fi
} > "$OUT_DIR/MACHINE-REPORT.txt"

log "WA-CHA_CANONICAL_BENCHMARK_END"

