$ErrorActionPreference = "Continue"
$RootDir = Split-Path -Parent $PSScriptRoot
$RepoDir = Join-Path $RootDir "proof-source"
$OutDir = Join-Path $RootDir "results/latest"
$RepoUrl = "https://github.com/openai/NavierStokesAndEuler.git"
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function Run-Logged {
  param([string]$Name, [scriptblock]$Command)
  $Log = Join-Path $OutDir "$Name.log"
  & $Command *> $Log
  $Code = $LASTEXITCODE
  Set-Content -Path (Join-Path $OutDir "$Name.exit-code") -Value $Code
  return $Code
}

Set-Content -Path (Join-Path $OutDir "environment.txt") -Value "UTC=$([DateTime]::UtcNow.ToString('o'))"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
  Set-Content -Path (Join-Path $OutDir "MACHINE-REPORT.txt") -Value "BLOCKED=git-not-found"
  exit 10
}

if (-not (Test-Path (Join-Path $RepoDir ".git"))) {
  $CloneCode = Run-Logged "clone" { git clone $RepoUrl $RepoDir }
  if ($CloneCode -ne 0) { exit 11 }
}

git -C $RepoDir rev-parse HEAD | Set-Content (Join-Path $OutDir "commit.txt")
git -C $RepoDir status --short | Set-Content (Join-Path $OutDir "git-status.txt")

if (-not (Get-Command lake -ErrorAction SilentlyContinue)) {
  Set-Content -Path (Join-Path $OutDir "MACHINE-REPORT.txt") -Value "BLOCKED=lake-not-found; install elan from https://lean-lang.org/install/"
  exit 12
}

lake --version | Add-Content (Join-Path $OutDir "environment.txt")
lean --version | Add-Content (Join-Path $OutDir "environment.txt")

Push-Location $RepoDir
$CacheCode = Run-Logged "cache" { lake exe cache get }
$BuildCode = Run-Logged "build" { lake build }
$MainCode = Run-Logged "main-theorem" { lake env lean NavierStokes.lean }

if ((Get-Command landrun -ErrorAction SilentlyContinue) -and
    (Get-Command lean4export -ErrorAction SilentlyContinue) -and
    (Get-Command nanoda_bin -ErrorAction SilentlyContinue)) {
  $ComparatorCode = Run-Logged "comparator" { lake exe comparator ComparatorChallenges/NavierStokes.json }
} else {
  $ComparatorCode = 125
  Set-Content -Path (Join-Path $OutDir "comparator.log") -Value "SKIPPED: optional Comparator binaries missing"
}
Pop-Location

$Patterns = '\bsorry\b|\badmit\b|\baxiom\b|\bunsafe\b'
Get-ChildItem -Path $RepoDir -Recurse -Filter *.lean |
  Select-String -Pattern $Patterns |
  Set-Content (Join-Path $OutDir "source-scan.txt")

$Status = if (($BuildCode -eq 0) -and ($MainCode -eq 0)) { "INDEPENDENTLY_COMPILED" } else { "FAILED_OR_BLOCKED" }
@(
  "BUILD_EXIT=$BuildCode"
  "MAIN_THEOREM_EXIT=$MainCode"
  "COMPARATOR_EXIT=$ComparatorCode"
  "PRELIMINARY_STATUS=$Status"
) | Set-Content (Join-Path $OutDir "MACHINE-REPORT.txt")

exit 0

